<?php
function getModuleNameListGenerated()
{
	$modules = null;

	return $modules;
}
?>
